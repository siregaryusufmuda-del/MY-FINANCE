# MY FINANCE — Android project

Project Android sederhana yang menampilkan aplikasi keuangan MY FINANCE melalui WebView. File antarmuka berada di `app/src/main/assets/my_finance.html`.

## Membuat APK dengan Android Studio
1. Ekstrak ZIP proyek ini.
2. Buka Android Studio dan pilih **Open**, lalu pilih folder `MyFinanceAndroid`.
3. Tunggu Gradle sync selesai. Gunakan JDK 17 dan Android SDK Platform 35.
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

## Membuat APK melalui GitHub Actions
1. Buat repository baru di GitHub dan unggah seluruh isi folder proyek ini.
2. Buka tab **Actions**, pilih **Build MY FINANCE APK**, lalu tekan **Run workflow**.
3. Setelah proses selesai, buka hasil run dan unduh artifact `my-finance-debug-apk`.
4. Ekstrak artifact untuk mendapatkan `app-debug.apk`.

## Catatan
- Data transaksi, utang, dan tabungan disimpan di penyimpanan lokal WebView pada perangkat dan tidak otomatis tersinkron ke perangkat lain.
- Gunakan fitur **Ekspor data** secara berkala untuk membuat cadangan JSON.
- APK yang dibuat adalah APK debug untuk penggunaan pribadi/uji coba, bukan APK release untuk distribusi publik.
- Fitur inti dapat digunakan tanpa koneksi internet setelah aplikasi terpasang.
