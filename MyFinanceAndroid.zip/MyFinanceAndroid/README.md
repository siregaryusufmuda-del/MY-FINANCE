# MY FINANCE — Android project

Aplikasi Android sederhana yang membungkus MY FINANCE dalam WebView. Antarmuka dan fitur pencatatan berasal dari `app/src/main/assets/my_finance.html`.

## Build APK lewat GitHub Actions

1. Upload seluruh isi folder project ini ke repository GitHub.
2. Buka tab **Actions**, pilih **Build MY FINANCE APK**, lalu tekan **Run workflow**.
3. Setelah selesai, buka hasil run dan unduh artifact `my-finance-debug-apk`.
4. Ekstrak artifact untuk mendapatkan `app-debug.apk`.

## Catatan

- Data disimpan di penyimpanan lokal WebView pada perangkat dan tidak otomatis tersinkron ke perangkat lain.
- Gunakan tombol **Ekspor data** secara berkala untuk membuat cadangan JSON.
- APK yang dibuat adalah APK debug untuk penggunaan pribadi/uji coba.
- Fitur inti dapat digunakan tanpa koneksi internet setelah aplikasi terpasang.
