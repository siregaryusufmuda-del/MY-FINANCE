# MY FINANCE — Android project

Aplikasi Android MY FINANCE dengan autentikasi akun dan sinkronisasi data ke Supabase. Antarmuka tetap memakai HTML/CSS/JavaScript di `app/src/main/assets/my_finance.html`.

## Fitur tahap cloud

- Daftar akun dengan email dan kata sandi melalui Supabase Auth.
- Login dan logout.
- Data transaksi, utang/cicilan, dan tabungan disimpan per akun di tabel `public.finance_data`.
- Sinkronisasi otomatis setelah perubahan data (membutuhkan internet).
- Data lokal per akun tetap disimpan sebagai cache dan fitur ekspor/impor JSON tetap tersedia.
- Aplikasi memakai Supabase publishable key; jangan pernah menaruh secret/service-role key di aplikasi.

## Database Supabase

Jalankan skema SQL yang disediakan pada tahap sebelumnya. Tabel `public.finance_data` harus memiliki kolom `id`, `user_id` (UNIQUE, FK ke `auth.users`), `data` (JSONB), dan `updated_at`, dengan Row Level Security aktif dan policy yang membatasi setiap baris ke `auth.uid() = user_id`.

Project URL dan publishable key diatur pada bagian konfigurasi awal `my_finance.html`. Publishable key memang boleh berada di aplikasi klien; keamanan data tetap bergantung pada RLS. Jangan pernah memasukkan secret key atau service-role key.

## Penting sebelum memasang versi cloud

Versi ini memakai origin WebView yang aman (`https://appassets.androidplatform.net`) agar koneksi HTTPS ke Supabase berjalan dengan aman. Karena origin penyimpanan WebView berubah dari versi lama (`file://`), **ekspor data dari aplikasi versi lama terlebih dahulu** melalui tombol Ekspor Data. Setelah masuk ke akun di versi cloud, gunakan Impor Data untuk memasukkan file cadangan tersebut. Jangan hapus versi lama sebelum file cadangan berhasil dibuat dan disimpan.

## Build APK lewat GitHub Actions

1. Upload seluruh isi folder project ini ke repository GitHub.
2. Buka tab **Actions**, pilih **Build MY FINANCE APK**, lalu tekan **Run workflow**.
3. Setelah selesai, buka hasil run dan unduh artifact `my-finance-debug-apk`.
4. Ekstrak artifact untuk mendapatkan `app-debug.apk`.

APK debug cocok untuk pengujian. Untuk distribusi publik, siapkan signing release, kebijakan privasi, dan pengujian keamanan sebelum publikasi.
